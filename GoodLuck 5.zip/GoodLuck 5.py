import tkinter as tk
import random
import string

# ------------- ρυθμίσεις ----------------
font_size = 20
speed = 50
chars = string.ascii_letters + string.digits + "@#$%&*"
trail_length = 20

# AI text
ai_message = "Good Luck...   Remember I Made This World...   I Made You..."
ai_index = 0

# ------------- main window ----------------
root = tk.Tk()
root.attributes('-fullscreen', True)
root.configure(bg='black')
width = root.winfo_screenwidth()
height = root.winfo_screenheight()

canvas = tk.Canvas(root, width=width, height=height, bg='black', highlightthickness=0)
canvas.pack(fill=tk.BOTH, expand=True)

# text box για AI
text_var = tk.StringVar()
text_label = tk.Label(root, textvariable=text_var, font=('Consolas', 20), fg='lightgreen', bg='black', justify='left')
text_label.place(x=20, y=height-50)

# secret exit
keys_pressed = set()

def key_down(event):
    keys_pressed.add(event.keysym)
    if ('Control_L' in keys_pressed or 'Control_R' in keys_pressed) and \
       ('Shift_L' in keys_pressed or 'Shift_R' in keys_pressed) and \
       ('Alt_L' in keys_pressed or 'Alt_R' in keys_pressed) and \
       'c' in keys_pressed:
        root.destroy()

def key_up(event):
    if event.keysym in keys_pressed:
        keys_pressed.remove(event.keysym)

root.bind("<KeyPress>", key_down)
root.bind("<KeyRelease>", key_up)

# ------------- Matrix columns ----------------
columns = width // font_size
drops = [random.randint(-trail_length, 0) for _ in range(columns)]

# ------------- draw function ----------------
def draw_matrix():
    canvas.delete("all")
    for i in range(columns):
        x = i * font_size
        for j in range(trail_length):
            y = (drops[i] - j) * font_size
            if 0 <= y < height:
                brightness = 255 - int((j / trail_length) * 200)
                color = f'#{0:02x}{brightness:02x}{0:02x}'
                canvas.create_text(x, y, text=random.choice(chars), fill=color, font=('Consolas', font_size, 'bold'))
        drops[i] += 1
        if drops[i] - trail_length > height // font_size:
            drops[i] = random.randint(-trail_length, 0)
    root.after(speed, draw_matrix)

# ------------- AI typing function ----------------
def type_ai():
    global ai_index
    if ai_index < len(ai_message):
        text_var.set(ai_message[:ai_index+1])
        ai_index += 1
        root.after(1000, type_ai)  # 300ms για κάθε γράμμα
    else:
        # αφού τελειώσει, κρατάει το μήνυμα
        text_var.set(ai_message)

draw_matrix()
type_ai()
root.mainloop()
